<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ContactForm;
use App\Http\Resources\ContactFormResource;
use Illuminate\Http\Request;

class ContactFormController extends Controller
{
    public function index()
    {
        $contactForms = ContactForm::latest()->paginate(10);
        return ContactFormResource::collection($contactForms);
    }

    public function show(ContactForm $contactForm)
    {
        return new ContactFormResource($contactForm);
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'name' => 'required|max:255',
            'email' => 'required|email',
            'message' => 'required'
        ]);

        $contactForm = ContactForm::create($validatedData);
        return new ContactFormResource($contactForm);
    }

    public function destroy(ContactForm $contactForm)
    {
        $contactForm->delete();
        return response()->json(null, 204);
    }
}